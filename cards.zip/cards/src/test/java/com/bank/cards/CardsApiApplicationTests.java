package com.bank.cards;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
